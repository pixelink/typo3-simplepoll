# typo3-simplepoll

<a href="https://codeclimate.com/github/pixelink/typo3-simplepoll"><img src="https://codeclimate.com/github/pixelink/typo3-simplepoll/badges/gpa.svg" /></a>

###An easy to use poll extension for TYPO3 6.2+

###Features
* easy to setup
* flexible to use
* multi lingual (de/en included)
* IP and/or cookie protection for multiple votes
* AJAX calls for all actions
