﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _start:

=============================================================
Simple Poll (Deutsch)
=============================================================

.. only:: html

	:Klassifikation:
		extension_key

	:Version:
		|release|

	:Sprache:
		de

	:Beschreibung:
		Geben Sie eine Beschreibung ein.

	:Schlüsselwörter:
		komma-getrennte,Liste,von,Schlüsselwörtern

	:Copyright:
		2014

	:Autor:
		Alex Bigott

	:E-Mail:
		author@example.com

	:Lizenz:
		Dieses Dokument wird unter der Open Content License, siehe
		http://www.opencontent.org/opl.shtml veröffentlicht.

	:Gerendert:
		|today|

	Der Inhalt dieses Dokuments bezieht sich auf TYPO3,
	ein GNU/GPL CMS-Framework auf `www.typo3.org <http://www.typo3.org/>`_.


	**Inhaltsverzeichnis**

.. toctree::
	:maxdepth: 5
	:titlesonly:
	:glob:

..	Introduction/Index
..	UsersManual/Index
..	AdministratorManual/Index
